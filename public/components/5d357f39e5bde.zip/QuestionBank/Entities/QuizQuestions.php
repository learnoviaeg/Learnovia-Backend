<?php

namespace Modules\QuestionBank\Entities;

use Illuminate\Database\Eloquent\Model;

class quiz_questions extends Model
{
    protected $fillable = [];
}
