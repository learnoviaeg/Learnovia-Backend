<?php

return [
    'name' => 'QuestionBank'
];
